import json
import requests

#If the event type is a CommentCreatedEvent, write to the comment DB
#Use the insertCommentLambda API
#Note: Event is a dictionary
def lambda_handler(event, context):
    if(event['Records'][0]['eventName']=='INSERT'):
        newImg = event['Records'][0]['dynamodb']['NewImage']
        
        if(newImg['type']['S']=='CommentCreatedEvent'):
            eventCore = newImg['data']['M']
            
            url = "https://i7hv4g41ze.execute-api.us-west-2.amazonaws.com/alpha/insertCommentLambda"
            payload = { 'commentID': eventCore['commentID']['S'],
                        'postID': eventCore['postID']['S'],
                        'userID': eventCore['userID']['S'],
                        'parentID': eventCore['parentID']['S'],
                        'content': eventCore['content']['S'],
                        'dateMs': int(eventCore['dateMs']['N'])
                      }
            r = requests.post(url, json=payload)
            print(r.text)            
            return {
                'statusCode': 200,
            }